PROGRAMMING 1A - REGISTRATION AND LOGIN

Open this folder as a Maven project in Apache NetBeans IDE 28.
Files:
- src/main/java/Login.java
- src/main/java/Main.java
- src/test/java/LoginTest.java
- pom.xml

Run Main.java for the registration/login program.
Run LoginTest.java or the Maven test goal for Question 4.

Suggested valid input:
kyl_1
Ch&&sec@ke99!
+27838968976

Regex reference:
Oracle (2026), Pattern (Java SE 26 API Documentation).
https://docs.oracle.com/en/java/javase/26/docs/api/java.base/java/util/regex/Pattern.html
