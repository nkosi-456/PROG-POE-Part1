import java.util.regex.Pattern;

public class Login {
    private String username;
    private String password;
    private String cellPhoneNumber;

    public Login(String username, String password, String cellPhoneNumber) {
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        if (password.length() < 8) return false;
        boolean hasCapitalLetter = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;
        for (int i = 0; i < password.length(); i++) {
            char character = password.charAt(i);
            if (Character.isUpperCase(character)) hasCapitalLetter = true;
            if (Character.isDigit(character)) hasNumber = true;
            if (!Character.isLetterOrDigit(character)) hasSpecialCharacter = true;
        }
        return hasCapitalLetter && hasNumber && hasSpecialCharacter;
    }

    /* Regex reference: Oracle (2026), Pattern (Java SE 26 API Documentation). */
    public boolean checkCellPhoneNumber() {
        String cellPhoneRegex = "^\\+27[0-9]{1,10}$";
        return Pattern.matches(cellPhoneRegex, cellPhoneNumber);
    }

    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        } else if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        } else {
            return "User has been successfully registered.";
        }
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return enteredUsername.equals(username) && enteredPassword.equals(password);
    }

    public String returnLoginStatus(boolean loginStatus) {
        if (loginStatus) return "Welcome " + username + ", it is great to see you again.";
        return "Username or password incorrect, please try again.";
    }
}
