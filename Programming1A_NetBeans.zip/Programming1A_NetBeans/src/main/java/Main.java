import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("=================================");
        System.out.println("       REGISTRATION SYSTEM");
        System.out.println("=================================");

        System.out.print("Enter username: ");
        String username = input.nextLine();
        System.out.print("Enter password: ");
        String password = input.nextLine();
        System.out.print("Enter South African cell phone number: ");
        String cellPhoneNumber = input.nextLine();

        Login user = new Login(username, password, cellPhoneNumber);

        System.out.println("\n--------- REGISTRATION RESULTS ---------");
        if (user.checkUserName()) System.out.println("Username successfully captured.");
        else System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
        if (user.checkPasswordComplexity()) System.out.println("Password successfully captured.");
        else System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
        if (user.checkCellPhoneNumber()) System.out.println("Cell number successfully captured.");
        else System.out.println("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.");

        System.out.println("\n--------- REGISTER USER ---------");
        System.out.println(user.registerUser());

        if (user.checkUserName() && user.checkPasswordComplexity() && user.checkCellPhoneNumber()) {
            System.out.println("\n=================================");
            System.out.println("             LOGIN");
            System.out.println("=================================");
            System.out.print("Enter username: ");
            String enteredUsername = input.nextLine();
            System.out.print("Enter password: ");
            String enteredPassword = input.nextLine();
            boolean loginStatus = user.loginUser(enteredUsername, enteredPassword);
            System.out.println("\n" + user.returnLoginStatus(loginStatus));
        }
        input.close();
    }
}
