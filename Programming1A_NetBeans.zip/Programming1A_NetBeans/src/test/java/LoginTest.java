import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

public class LoginTest {
    @Test public void testUsernameCorrectlyFormatted() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(true, user.checkUserName());
    }
    @Test public void testUsernameIncorrectlyFormatted() {
        Login user = new Login("kyle !!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(false, user.checkUserName());
    }
    @Test public void testPasswordMeetsComplexity() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(true, user.checkPasswordComplexity());
    }
    @Test public void testPasswordDoesNotMeetComplexity() {
        Login user = new Login("kyl_1", "password", "+27838968976");
        assertEquals(false, user.checkPasswordComplexity());
    }
    @Test public void testCellPhoneCorrectlyFormatted() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(true, user.checkCellPhoneNumber());
    }
    @Test public void testCellPhoneIncorrectlyFormatted() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "08966553");
        assertEquals(false, user.checkCellPhoneNumber());
    }
    @Test public void testLoginSuccessful() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(user.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }
    @Test public void testLoginUnsuccessful() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(user.loginUser("wrong_username", "wrong_password"));
    }
    @Test public void testRegisterUserSuccessfully() {
        Login user = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("User has been successfully registered.", user.registerUser());
    }
    @Test public void testRegisterUserIncorrectPassword() {
        Login user = new Login("kyl_1", "password", "+27838968976");
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", user.registerUser());
    }
}
